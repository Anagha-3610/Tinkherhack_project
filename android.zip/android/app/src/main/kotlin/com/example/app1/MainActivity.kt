package com.example.app1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
