import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xFF66545e);
  static const secondaryColor = Color(0xFFf6e0b5);
  static const accentColor = Color(0xFFa39193);
}
