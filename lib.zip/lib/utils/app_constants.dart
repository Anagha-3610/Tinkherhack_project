class AppConstants {
  static const String appTitle = 'RE-VISION';
}
