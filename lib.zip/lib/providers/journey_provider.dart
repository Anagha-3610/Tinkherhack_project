import 'package:flutter/material.dart';

class JourneyProvider with ChangeNotifier {
  String? _start;
  String? _end;

  String? get start => _start;
  String? get end => _end;

  void setJourney(String start, String end) {
    _start = start;
    _end = end;
    notifyListeners();
  }
}
