import 'package:flutter/material.dart';

class ProfileProvider with ChangeNotifier {
  String? _name;
  String? _email;

  String? get name => _name;
  String? get email => _email;

  void setProfile(String name, String email) {
    _name = name;
    _email = email;
    notifyListeners();
  }
}
