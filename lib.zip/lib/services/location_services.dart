import 'package:flutter/material.dart';

class LocationService {
  Future<String> getLocation() async {
    // Simulate fetching user's location
    await Future.delayed(Duration(seconds: 2));
    return 'New York, USA';
  }
}
