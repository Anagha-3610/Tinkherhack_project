import 'package:flutter/material.dart';
import 'screens/login_page.dart';
import 'screens/journey_page.dart';
import 'screens/profile_page.dart';
import 'screens/maps_page.dart';
import 'routes/app_routes.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Journey App',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: AppRoutes.login,
      routes: {
        AppRoutes.login: (context) => LoginPage(),
        AppRoutes.journey: (context) => JourneyPage(),
        AppRoutes.profile: (context) => ProfilePage(),
        AppRoutes.maps: (context) => MapsPage(),
      },
    );
  }
}
