// lib/screens/profile_screen.dart
import 'package:flutter/material.dart';
import '../models/user.dart';
import '../widgets/user_profile_widget.dart';

class ProfileScreen extends StatelessWidget {
  // Sample User Data
  final User user = User(
    id: '1',
    name: 'John Doe',
    email: 'john.doe@example.com',
    profilePicture: 'https://www.example.com/profile_pic.jpg',
    closeOnes: ['Alice', 'Bob', 'Charlie'],
    isLiveSharingEnabled: true,
  );

  @override
  Widget build(BuildContext context) {
    return UserProfileWidget(user: user);
  }
}
