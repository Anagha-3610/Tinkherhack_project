import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';
import '../widgets/text_field_widget.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sign Up')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFieldWidget(label: 'Name'),
            SizedBox(height: 20),
            TextFieldWidget(label: 'Phone Number'),
            SizedBox(height: 20),
            CustomButton(
              label: 'Sign Up',
              onPressed: () {
                // Add your sign-up logic here
                Navigator.pushNamed(context, '/welcome');
              },
            ),
          ],
        ),
      ),
    );
  }
}
