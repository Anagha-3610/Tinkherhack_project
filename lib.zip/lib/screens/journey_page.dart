import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class JourneyPage extends StatefulWidget {
  @override
  _JourneyPageState createState() => _JourneyPageState();
}

class _JourneyPageState extends State<JourneyPage> {
  final TextEditingController _startController = TextEditingController();
  final TextEditingController _endController = TextEditingController();

  GoogleMapController? _mapController;
  LatLng? _startLatLng;
  LatLng? _endLatLng;

  Set<Polyline> _polylines = {};
  final String _googleApiKey = "AIzaSyBkFla8ZUzf_-NdQSeO6WY_G8IJOYwCFyw";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Plan Your Journey"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  controller: _startController,
                  decoration: const InputDecoration(
                    labelText: "Start Location",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _endController,
                  decoration: const InputDecoration(
                    labelText: "End Location",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: _searchRoute,
                  child: const Text("Search Route"),
                ),
              ],
            ),
          ),
          Expanded(
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(20.5937, 78.9629), // Default to India
                zoom: 5,
              ),
              onMapCreated: (GoogleMapController controller) {
                _mapController = controller;
              },
              markers: _createMarkers(),
              polylines: _polylines,
            ),
          ),
        ],
      ),
    );
  }

  Set<Marker> _createMarkers() {
    final markers = <Marker>{};
    if (_startLatLng != null) {
      markers.add(
        Marker(
          markerId: const MarkerId("start"),
          position: _startLatLng!,
          infoWindow: const InfoWindow(title: "Start Location"),
        ),
      );
    }
    if (_endLatLng != null) {
      markers.add(
        Marker(
          markerId: const MarkerId("end"),
          position: _endLatLng!,
          infoWindow: const InfoWindow(title: "End Location"),
        ),
      );
    }
    return markers;
  }

  Future<void> _searchRoute() async {
    if (_startController.text.isEmpty || _endController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter both locations")),
      );
      return;
    }

    try {
      // Geocode the start and end locations
      List<Location> startLocations =
          await locationFromAddress(_startController.text);
      List<Location> endLocations =
          await locationFromAddress(_endController.text);

      if (startLocations.isNotEmpty && endLocations.isNotEmpty) {
        setState(() {
          _startLatLng = LatLng(
              startLocations.first.latitude, startLocations.first.longitude);
          _endLatLng =
              LatLng(endLocations.first.latitude, endLocations.first.longitude);
        });

        _getRoutePolyline();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error finding locations: $e")),
      );
    }
  }

  Future<void> _getRoutePolyline() async {
    if (_startLatLng == null || _endLatLng == null) return;

    final String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=${_startLatLng!.latitude},${_startLatLng!.longitude}&destination=${_endLatLng!.latitude},${_endLatLng!.longitude}&key=$_googleApiKey";

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data["routes"].isNotEmpty) {
          final points = data["routes"][0]["overview_polyline"]["points"];
          final polylinePoints = _decodePolyline(points);

          setState(() {
            _polylines = {
              Polyline(
                polylineId: const PolylineId("route"),
                points: polylinePoints,
                color: Colors.blue,
                width: 5,
              ),
            };
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("No route found")),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching route: $e")),
      );
    }
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }
}
