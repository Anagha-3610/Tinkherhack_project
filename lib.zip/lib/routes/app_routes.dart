class AppRoutes {
  static const String login = '/login';
  static const String journey = '/journey';
  static const String profile = '/profile';
  static const String maps = '/maps';
}
