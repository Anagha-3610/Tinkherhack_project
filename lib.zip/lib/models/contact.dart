// lib/models/contact.dart
class Contact {
  final String id;
  final String name;
  final String phoneNumber;
  final String
      relationship; // Relationship with the user (e.g., 'Friend', 'Family')

  Contact({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.relationship,
  });
}
