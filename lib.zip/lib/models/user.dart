// lib/models/user.dart
class User {
  final String id;
  final String name;
  final String email;
  final String profilePicture;
  final List<String>
      closeOnes; // List of close ones (could be names, IDs, etc.)
  final bool isLiveSharingEnabled; // Flag to indicate if live sharing is on

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.profilePicture,
    required this.closeOnes,
    required this.isLiveSharingEnabled,
  });
}
