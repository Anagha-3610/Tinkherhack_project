// lib/widgets/user_profile_widget.dart
import 'package:flutter/material.dart';
import '../models/user.dart';

class UserProfileWidget extends StatelessWidget {
  final User user;

  UserProfileWidget({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profile Picture and Name
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(user.profilePicture),
            ),
            SizedBox(height: 16),
            Text(
              user.name,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              user.email,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 20),

            // Close Ones Section
            Text(
              'Close Ones',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: user.closeOnes.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Icon(Icons.person),
                    title: Text(user.closeOnes[index]),
                    trailing: Icon(Icons.message),
                    onTap: () {
                      // Handle tapping on a close one
                    },
                  );
                },
              ),
            ),

            // Live Location Sharing Switch
            SizedBox(height: 20),
            SwitchListTile(
              title: Text('Live Location Sharing'),
              value: user.isLiveSharingEnabled,
              onChanged: (bool value) {
                // Handle live location sharing toggle
                // You can update the user's setting here
              },
            ),
          ],
        ),
      ),
    );
  }
}
