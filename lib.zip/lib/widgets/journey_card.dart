import 'package:flutter/material.dart';

class JourneyCard extends StatelessWidget {
  final String start;
  final String end;

  JourneyCard({required this.start, required this.end});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text('$start to $end'),
        trailing: Icon(Icons.directions),
      ),
    );
  }
}
