// lib/widgets/contact_widget.dart
import 'package:flutter/material.dart';
import '../models/contact.dart';

class ContactWidget extends StatelessWidget {
  final Contact contact;

  ContactWidget({required this.contact});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        leading: Icon(Icons.person, size: 40, color: Colors.blue),
        title: Text(
          contact.name,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              contact.relationship,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 4),
            Text(
              contact.phoneNumber,
              style: TextStyle(
                fontSize: 14,
                color: Colors.blue,
              ),
            ),
          ],
        ),
        trailing: IconButton(
          icon: Icon(Icons.call),
          color: Colors.green,
          onPressed: () {
            // Implement action to make a call or other functionality
            print('Calling ${contact.name}...');
          },
        ),
      ),
    );
  }
}
